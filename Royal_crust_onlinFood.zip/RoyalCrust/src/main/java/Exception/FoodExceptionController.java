package Exception;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.ControllerAdvice;
//import org.springframework.web.bind.annotation.ExceptionHandler;
//
//@ControllerAdvice
//public class FoodExceptionController {
//	@ExceptionHandler(value = ClassNotFoundException.class)
//	   public ResponseEntity<Object> exception(ClassNotFoundException exception) {
//	      return new ResponseEntity<>("Food not found", HttpStatus.NOT_FOUND);
//	   }
//	}
//


