package Exception;
//
////import org.springframework.http.ResponseEntity;
////import org.springframework.web.bind.annotation.ExceptionHandler;
//
//public class FoodnNotFoundException extends RuntimeException {
//	
//	private static final long serialVersionUID = 1L;
//
//
////	@ExceptionHandler(value = ClassNotFoundException.class)
//
////	public ResponseEntity<Object> exception(ClassNotFoundException exception) {
//	
//
		



//	}
//}